# Boring State: Yeah!!!
print("Hello World")